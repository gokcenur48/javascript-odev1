let firstName=prompt("İsminizi giriniz :)")
let myName=document.querySelector("#myName")
myName.innerHTML=(`${myName.innerHTML} ${firstName}`)
function startTime()
{
 var d = new Date();
 var gunler= ["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"];
 var today=new Date();
 var h=today.getHours();
 var m=today.getMinutes();
 var s=today.getSeconds();

 h=checkTime(h);
 m=checkTime(m);
 s=checkTime(s);
 document.getElementById('myClock').innerHTML=h+":"+m+":"+s+ " "+gunler[d.getDay()];
 
}
startTime()
setInterval(startTime,1000);

function checkTime(i)
{
if (i<10)
 {
  i="0" + i;
 }
return i;
}
